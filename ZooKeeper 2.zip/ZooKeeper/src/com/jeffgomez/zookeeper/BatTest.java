package com.jeffgomez.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		System.out.println(" ----Bat 1 -----");
		Bat bat1 = new Bat();
		bat1.attackTown();
		bat1.attackTown();
		bat1.attackTown();
		bat1.eatHumans();
		bat1.eatHumans();
		bat1.fly();
		
		

	}

}
