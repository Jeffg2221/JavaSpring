package com.jeffgomez.zookeeper;

public class GorillaTest {

	public static void main(String[] args) {
		System.out.println(" ----Gorilla 1 -----");
		Gorilla gor1 = new Gorilla();
		gor1.throwSomething();
		gor1.throwSomething();
		gor1.throwSomething();
		gor1.eatBananas();
		gor1.eatBananas();
		gor1.climb();
		
				
	}

}
