package com.jeffgomez.bundler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BundlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BundlerApplication.class, args);
	}

}
